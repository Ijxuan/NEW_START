#ifndef SHOOT_CAN_H
#define SHOOT_CAN_H

void shoot_control(void);
void driver_plate_control(void);


#endif